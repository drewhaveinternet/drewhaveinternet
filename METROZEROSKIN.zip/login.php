<?php
session_start();

$nickname = "";
$error = "";
$success = false;

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = trim($_POST['id'] ?? '');
    $server = trim($_POST['server'] ?? '');

    if ($id === '' || $server === '') {
        $error = "Please enter both ID and Server.";
    } else {
        $api_url = "https://api.isan.eu.org/nickname/ml?id=" . urlencode($id) . "&server=" . urlencode($server) . "&decode=true";

        $response = @file_get_contents($api_url);

        if ($response === FALSE) {
            $error = "Error: Cannot reach API server. Please try again later.";
        } else {
            $data = json_decode($response, true);

            if (json_last_error() !== JSON_ERROR_NONE) {
                $error = "Error: Invalid API response format.";
            } elseif (empty($data) || !isset($data['name']) || $data['name'] === '') {
                $error = "ID and Server combination not found. Please check and try again.";
            } else {
                $nickname = htmlspecialchars($data['name']);
                $_SESSION['nickname'] = $nickname;
                $_SESSION['id'] = $id;           // Simpan juga ID dan server untuk nanti jika perlu
                $_SESSION['server'] = $server;

                header("Location: data.php");
                exit;
            }
        }
    }
}
?>


<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Login - Mobile Legends Redeem</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap');

  * {
    box-sizing: border-box;
  }
  body {
    margin: 0; padding: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #a7c7e7, #e6f0fa);
    color: #0b1a3b;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
  }

  header {
    background: #0a1837;
    padding: 12px 20px;
    display: flex;
    align-items: center;
  }
  header .logo img {
    height: 40px;
    width: auto;
  }
  .menu-toggle {
    margin-left: auto;
    cursor: pointer;
    display: flex;
    flex-direction: column;
    justify-content: center;
    gap: 5px;
    width: 28px;
  }
  .menu-toggle div {
    width: 100%;
    height: 3px;
    background-color: white;
    border-radius: 3px;
  }

  nav.sidebar {
    position: fixed;
    top: 56px;
    left: -260px;
    width: 260px;
    height: calc(100% - 56px);
    background: linear-gradient(180deg, #0a1837, #171e3e);
    box-shadow: 3px 0 10px rgba(0,0,0,0.8);
    padding: 20px;
    display: flex;
    flex-direction: column;
    gap: 15px;
    transition: left 0.3s ease;
    z-index: 1000;
  }
  nav.sidebar.active {
    left: 0;
  }
  nav.sidebar a {
    color: #9bb9f8;
    font-weight: 600;
    font-size: 16px;
    padding: 10px 15px;
    border-radius: 8px;
    text-decoration: none;
    transition: background-color 0.2s ease;
  }
  nav.sidebar a:hover,
  nav.sidebar a:focus {
    background-color: #0055ff;
    color: white;
    outline: none;
  }

  .overlay {
    position: fixed;
    top: 56px;
    left: 0;
    right: 0;
    bottom: 0;
    background-color: rgba(0,0,0,0.5);
    opacity: 0;
    pointer-events: none;
    transition: opacity 0.3s ease;
    z-index: 999;
  }
  .overlay.active {
    opacity: 1;
    pointer-events: auto;
  }

  main {
    flex-grow: 1;
    max-width: 420px;
    width: 90%;
    margin: 40px auto;
    background: white;
    padding: 25px 30px;
    border-radius: 14px;
    box-shadow: 0 8px 24px rgb(0 0 0 / 0.15);
  }

  main h1 {
    margin-top: 0;
    margin-bottom: 25px;
    font-weight: 700;
    font-size: 28px;
    color: #0a1837;
    text-align: center;
  }

  form {
    display: flex;
    flex-direction: column;
    gap: 18px;
  }
  label {
    font-weight: 600;
    font-size: 14px;
    margin-bottom: 6px;
    color: #34495e;
  }
  input[type="text"], input[type="number"] {
    padding: 10px 14px;
    border-radius: 8px;
    border: 1.8px solid #b0c4de;
    font-size: 16px;
    transition: border-color 0.3s ease;
  }
  input[type="text"]:focus, input[type="number"]:focus {
    border-color: #0055ff;
    outline: none;
  }

  button[type="submit"] {
    background: linear-gradient(45deg, #0055ff, #00aaff);
    border: none;
    color: white;
    font-weight: 700;
    font-size: 16px;
    padding: 12px 0;
    border-radius: 10px;
    cursor: pointer;
    box-shadow: 0 0 14px #00aaffcc;
    transition: box-shadow 0.3s ease, transform 0.2s ease;
  }
  button[type="submit"]:hover,
  button[type="submit"]:focus {
    box-shadow: 0 0 22px #00d1ffee, 0 0 34px #00b0ffcc;
    transform: scale(1.05);
    outline: none;
  }

  .player-info {
    margin-top: 28px;
    border: 1.5px solid #0055ff;
    border-radius: 10px;
    overflow: hidden;
  }
  .player-info table {
    width: 100%;
    border-collapse: collapse;
  }
  .player-info th,
  .player-info td {
    padding: 14px 20px;
    text-align: left;
    border-bottom: 1px solid #d6e4ff;
    font-size: 16px;
  }
  .player-info th {
    background-color: #cce5ff;
    color: #0055ff;
    font-weight: 700;
  }
  .player-info tr:last-child td {
    border-bottom: none;
  }

  .message {
    margin-top: 18px;
    padding: 14px 18px;
    border-radius: 12px;
    font-weight: 600;
    font-size: 17px;
    text-align: center;
  }
  .message.error {
    background: #ffe6e6;
    color: #c00;
    border: 1.8px solid #cc0000;
  }
  .message.success {
    background: #e6f4ff;
    color: #0055ff;
    border: 1.8px solid #0055ff;
  }

  @media (max-width: 480px) {
    main {
      padding: 20px 18px;
      width: 95%;
    }
  }
</style>
</head>
<body>

<header>
  <div class="logo" aria-label="Mobile Legends Logo">
    <img src="https://news-mlbb.event-redeem.com/img/assets/mlbb_logo.png" alt="Mobile Legends Logo" />
  </div>
  <div class="menu-toggle" role="button" tabindex="0" aria-label="Toggle sidebar menu" aria-expanded="false" aria-controls="sidebar">
    <div></div>
    <div></div>
    <div></div>
  </div>
</header>

<nav class="sidebar" id="sidebar" aria-label="Sidebar navigation" tabindex="-1">
  <a href="#" tabindex="0">Home</a>
  <a href="#" tabindex="0">Redeem</a>
  <a href="#" tabindex="0">Skins</a>
  <a href="#" tabindex="0">Profile</a>
  <a href="#" tabindex="0">Settings</a>
</nav>
<div class="overlay" tabindex="-1"></div>

<main>
  <h1>Login</h1>
  <form method="post" action="">
    <label for="id">ID</label>
    <input type="text" id="id" name="id" required placeholder="Enter your MLBB ID" value="<?= htmlspecialchars($_POST['id'] ?? '') ?>" />

    <label for="server">Server</label>
    <input type="number" id="server" name="server" required placeholder="Enter server number" value="<?= htmlspecialchars($_POST['server'] ?? '') ?>" min="1" />

    <button type="submit">Submit</button>
  </form>

  <?php if ($error): ?>
    <div class="message error" role="alert" aria-live="assertive"><?= $error ?></div>
  <?php elseif ($success): ?>
    <div class="message success" role="alert" aria-live="polite">
      Success! Welcome, <strong><?= $nickname ?></strong>.<br />
      Redirecting in <span id="countdown">5</span> seconds...
    </div>

    <section class="player-info" aria-label="Player information">
      <table>
        <thead>
          <tr><th>Nickname</th><th>ID</th><th>Server</th></tr>
        </thead>
        <tbody>
          <tr>
            <td><?= $nickname ?></td>
            <td><?= htmlspecialchars($id) ?></td>
            <td><?= htmlspecialchars($server) ?></td>
          </tr>
        </tbody>
      </table>
    </section>

    <script>
      let count = 5;
      const countdownEl = document.getElementById('countdown');

      const timer = setInterval(() => {
        count--;
        countdownEl.textContent = count;
        if (count <= 0) {
          clearInterval(timer);
          window.location.href = 'data.php';
        }
      }, 1000);
    </script>
  <?php endif; ?>
</main>

<script>
  const toggle = document.querySelector('.menu-toggle');
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.querySelector('.overlay');

  function openSidebar() {
    sidebar.classList.add('active');
    overlay.classList.add('active');
    toggle.setAttribute('aria-expanded', 'true');
    sidebar.focus();
  }

  function closeSidebar() {
    sidebar.classList.remove('active');
    overlay.classList.remove('active');
    toggle.setAttribute('aria-expanded', 'false');
    toggle.focus();
  }

  toggle.addEventListener('click', () => {
    if (sidebar.classList.contains('active')) {
      closeSidebar();
    } else {
      openSidebar();
    }
  });

  overlay.addEventListener('click', closeSidebar);

  toggle.addEventListener('keydown', (e) => {
    if (e.key === 'Enter' || e.key === ' ') {
      e.preventDefault();
      toggle.click();
    }
  });
  sidebar.addEventListener('keydown', (e) => {
    if (e.key === 'Escape') {
      closeSidebar();
    }
  });
</script>

</body>
</html>
