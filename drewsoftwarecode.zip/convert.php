<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Currency Converter - Drew Software</title>
  <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@400;600&display=swap" rel="stylesheet"/>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      font-family: 'Poppins', sans-serif;
      background: linear-gradient(to bottom right, #0f3a2e, #143c2c);
      color: #fff;
      min-height: 100vh;
      display: flex;
      flex-direction: column;
    }

    header {
      background-color: #14532d;
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 15px 25px;
    }

    header h1 {
      font-size: 1.4rem;
    }

    .menu-toggle {
      font-size: 1.8rem;
      cursor: pointer;
    }

    .container {
      flex: 1;
      display: flex;
      justify-content: center;
      align-items: center;
      padding: 20px;
    }

    .converter-box {
      background: rgba(255, 255, 255, 0.05);
      padding: 30px 25px;
      border-radius: 16px;
      max-width: 400px;
      width: 100%;
      box-shadow: 0 8px 20px rgba(0, 0, 0, 0.3);
      backdrop-filter: blur(6px);
    }

    .converter-box h2 {
      text-align: center;
      margin-bottom: 25px;
      font-size: 1.6rem;
    }

    input, select, button {
      width: 100%;
      padding: 12px;
      margin-bottom: 15px;
      border-radius: 8px;
      border: none;
      font-size: 1rem;
    }

    input, select {
      background-color: #111827;
      color: white;
    }

    button {
      background-color: #22c55e;
      font-weight: bold;
      color: white;
      cursor: pointer;
      transition: background 0.3s ease;
    }

    button:hover {
      background-color: #16a34a;
    }

    .result {
      text-align: center;
      font-weight: bold;
      margin: 20px 0;
      color: #22d3ee;
    }

    .history {
      background-color: rgba(255,255,255,0.07);
      padding: 10px 15px;
      border-radius: 8px;
      font-size: 0.9rem;
      color: #ccc;
      text-align: center;
    }

    .footer {
      background-color: #064e3b;
      text-align: center;
      padding: 15px;
      font-size: 0.85rem;
      color: #d1fae5;
    }

    .dark-toggle {
      position: absolute;
      top: 18px;
      right: 60px;
      cursor: pointer;
    }

    .logout-btn {
      background: none;
      border: 2px solid white;
      color: white;
      padding: 5px 12px;
      border-radius: 6px;
      font-size: 0.9rem;
      margin-left: 15px;
      cursor: pointer;
    }

    @media (max-width: 500px) {
      header h1 {
        font-size: 1.2rem;
      }

      .converter-box {
        padding: 25px 20px;
      }

      .dark-toggle {
        right: 50px;
      }
    }
  </style>
</head>
<body>
  <header>
  <h1>DREW SOFTWARE</h1>
  <div style="display: flex; align-items: center; gap: 10px;">
    <!-- Optional: Burger menu jika ingin -->
    <!-- <span class="menu-toggle">&#9776;</span> -->

    
  </div>
</header>


  <div class="dark-toggle" onclick="toggleDarkMode()">🌙</div>

  <div class="container">
    <div class="converter-box">
      <h2>Currency Converter</h2>
      <input type="number" id="amount" placeholder="Amount" />
      <select id="fromCurrency">
        <option value="IDR">IDR</option>
        <option value="USD">USD</option>
        <option value="MYR">MYR</option>
        <option value="SGD">SGD</option>
        <option value="EUR">EUR</option>
      </select>
      <select id="toCurrency">
        <option value="USD">USD</option>
        <option value="IDR">IDR</option>
        <option value="MYR">MYR</option>
        <option value="SGD">SGD</option>
        <option value="EUR">EUR</option>
      </select>
      <button onclick="convert()">Convert</button>
      <div class="result" id="result"></div>
      <div class="history" id="history"></div>
    </div>
  </div>

  <div class="footer">
    &copy; 2025 Drew Software. All rights reserved.
  </div>

  <script>
    const rates = {
      IDR: { USD: 0.000062, MYR: 0.00029, SGD: 0.000085, EUR: 0.000059 },
      USD: { IDR: 16000, MYR: 4.6, SGD: 1.35, EUR: 0.92 },
      MYR: { IDR: 3450, USD: 0.22, SGD: 0.30, EUR: 0.20 },
      SGD: { IDR: 11700, USD: 0.74, MYR: 3.3, EUR: 0.68 },
      EUR: { IDR: 17000, USD: 1.1, MYR: 5, SGD: 1.45 },
    };

    function convert() {
      const amount = parseFloat(document.getElementById("amount").value);
      const from = document.getElementById("fromCurrency").value;
      const to = document.getElementById("toCurrency").value;
      const resultDiv = document.getElementById("result");
      const historyDiv = document.getElementById("history");

      if (isNaN(amount) || !rates[from] || !rates[from][to]) {
        resultDiv.innerText = "Invalid input.";
        return;
      }

      const rate = rates[from][to];
      const result = amount * rate;
      resultDiv.innerText = `${amount} ${from} = ${result.toFixed(2)} ${to}`;
      historyDiv.innerText = `${amount} ${from} = ${result.toFixed(2)} ${to}`;
    }

    function toggleDarkMode() {
      const body = document.body;
      body.classList.toggle("dark");

      if (body.classList.contains("dark")) {
        body.style.background = "#111";
      } else {
        body.style.background = "linear-gradient(to bottom right, #0f3a2e, #143c2c)";
      }
    }
  </script>
</body>
</html>
