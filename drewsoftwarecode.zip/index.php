<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Drew Software - Secure Uplink</title>
  <link href="https://fonts.googleapis.com/css2?family=Fira+Code&display=swap" rel="stylesheet" />
  <style>
    * {
      margin: 0; padding: 0; box-sizing: border-box;
    }
    body {
      font-family: 'Fira Code', monospace;
      background: #0d0d0d;
      color: #00ff88;
      overflow: hidden;
    }

    /* Navbar */
    .navbar {
      position: fixed;
      top: 0;
      width: 100%;
      padding: 15px 30px;
      display: flex;
      justify-content: space-between;
      align-items: center;
      background: rgba(0, 0, 0, 0.6);
      border-bottom: 1px solid #00ff88;
      z-index: 10;
    }
    .navbar .logo {
      font-weight: bold;
      font-size: 1.2rem;
      color: #00ff88;
    }
    .navbar .login-btn {
      background: transparent;
      border: 1px solid #00ff88;
      color: #00ff88;
      padding: 6px 16px;
      cursor: pointer;
      transition: all 0.3s;
    }
    .navbar .login-btn:hover {
      background: #00ff88;
      color: #0d0d0d;
    }

    /* Terminal box */
    .terminal {
      position: absolute;
      top: 55%;
      left: 50%;
      transform: translate(-50%, -50%);
      width: 90%;
      max-width: 900px;
      height: 500px;
      background: rgba(0, 0, 0, 0.85);
      border: 2px solid #00ff88;
      padding: 20px;
      box-shadow: 0 0 25px #00ff88;
      overflow-y: auto;
      font-size: 14px;
      line-height: 1.4;
      white-space: pre-wrap;
      z-index: 1;
    }

    .glow {
      animation: glow 1.5s ease-in-out infinite alternate;
    }
    @keyframes glow {
      from { text-shadow: 0 0 10px #00ff88; }
      to { text-shadow: 0 0 20px #00ff88, 0 0 30px #00ff88; }
    }

    /* Matrix background canvas */
    canvas#matrixCanvas {
      position: fixed;
      top: 0; left: 0;
      width: 100vw;
      height: 100vh;
      z-index: -1;
      background: #000;
    }

    @media (max-width: 768px) {
      .terminal {
        height: 400px;
        font-size: 13px;
      }
    }
  </style>
</head>
<body>
  <!-- Background -->
  <canvas id="matrixCanvas"></canvas>

  <!-- Navbar -->
  <div class="navbar">
    <div class="logo">DREW SOFTWARE</div>
    <button class="login-btn" onclick="location.href='login.html'">Login</button>
  </div>

  <!-- Terminal Live Code -->
  <div class="terminal glow" id="codeArea">// Initializing Drew Software System...</div>

  <!-- Script -->
  <script>
    // MATRIX BACKGROUND
    const canvas = document.getElementById("matrixCanvas");
    const ctx = canvas.getContext("2d");

    canvas.width = window.innerWidth;
    canvas.height = window.innerHeight;

    const katakana = "アカサタナハマヤラワ0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    const columns = canvas.width / 14;
    const drops = Array.from({length: columns}).fill(1);

    function drawMatrix() {
      ctx.fillStyle = "rgba(0, 0, 0, 0.05)";
      ctx.fillRect(0, 0, canvas.width, canvas.height);
      ctx.fillStyle = "#00ff88";
      ctx.font = "14px monospace";

      for (let i = 0; i < drops.length; i++) {
        const text = katakana.charAt(Math.floor(Math.random() * katakana.length));
        ctx.fillText(text, i * 14, drops[i] * 14);
        drops[i]++;
        if (drops[i] * 14 > canvas.height && Math.random() > 0.975) drops[i] = 0;
      }
    }
    setInterval(drawMatrix, 35);
    window.addEventListener('resize', () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    });

    // LIVE CODE
    const codeArea = document.getElementById("codeArea");
    const codeString = `
/* System Boot Sequence - Drew Software Secure Uplink */

const SYSTEM_KEY = generateKey(256);
const SATELLITE_IP = '192.168.127.40';
let uplinkStatus = false;

async function initializeUplink() {
  console.log('>>> Booting core modules...');
  await delay(1000);

  console.log('>>> Authenticating system ID...');
  const isAuth = await authenticate('DREW_CORE');

  if (!isAuth) {
    throw new Error('>>> AUTHENTICATION FAILED');
  }

  console.log('>>> Link established with satellite at', SATELLITE_IP);
  uplinkStatus = true;

  await injectPayload();
}

function generateKey(bits) {
  return crypto.getRandomValues(new Uint8Array(bits / 8)).join('-');
}

function delay(ms) {
  return new Promise(resolve => setTimeout(resolve, ms));
}

function authenticate(id) {
  return new Promise(res => {
    setTimeout(() => res(id === 'DREW_CORE'), 1200);
  });
}

async function injectPayload() {
  console.log('>>> Uploading payload...');
  await delay(2000);
  console.log('>>> Payload delivered. System synced.');
}

initializeUplink().catch(console.error);
`.trim();

    let index = 0;
    function typeCodeChar() {
      if (index < codeString.length) {
        const currentChar = codeString.charAt(index);
        codeArea.innerHTML += currentChar === "\n" ? "<br>" : currentChar === " " ? "&nbsp;" : currentChar;
        codeArea.scrollTop = codeArea.scrollHeight;
        index++;
        setTimeout(typeCodeChar, 12);
      }
    }

    setTimeout(typeCodeChar, 800);
  </script>
</body>
</html>
