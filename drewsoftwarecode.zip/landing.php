<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <title>Drew Software - Portfolio</title>
  <link href="https://fonts.googleapis.com/css2?family=Fira+Code&display=swap" rel="stylesheet" />
  <style>
    body {
      margin: 0;
      font-family: 'Fira Code', monospace;
      background-color: #0d1117;
      color: #c9d1d9;
    }
    header {
      display: flex;
      justify-content: space-between;
      align-items: center;
      padding: 1rem 2rem;
      background-color: #161b22;
      position: sticky;
      top: 0;
      z-index: 100;
      flex-wrap: wrap;
    }
    .logo {
      font-size: 1.5rem;
      font-weight: bold;
      color: #58a6ff;
    }
    .menu-toggle {
      display: none;
      font-size: 1.5rem;
      background: none;
      color: white;
      border: none;
      cursor: pointer;
    }
    nav {
      display: flex;
      gap: 1rem;
    }
    nav a {
      color: #c9d1d9;
      text-decoration: none;
      font-size: 0.9rem;
    }
    section {
      padding: 3rem 2rem;
    }
    h2 {
      color: #58a6ff;
    }
    .project, .article {
      margin-bottom: 2rem;
      background: #161b22;
      padding: 1.5rem;
      border-radius: 12px;
      box-shadow: 0 0 8px rgba(255,255,255,0.05);
    }
    .live-code-box, .stock-animation {
      background: #0d1117;
      border: 1px solid #30363d;
      padding: 1rem;
      border-radius: 12px;
      margin-top: 1rem;
      color: #7ee787;
      font-size: 0.9rem;
      overflow-x: auto;
    }

    .converter-section {
      padding: 3rem 1rem;
      background: #0d1117;
      text-align: center;
    }
    .converter-box {
      background: linear-gradient(145deg, #161b22, #0d1117);
      padding: 2rem;
      border-radius: 16px;
      max-width: 420px;
      margin: auto;
      box-shadow: 0 0 16px rgba(88,166,255,0.1);
    }
    .converter-box label {
      display: block;
      text-align: left;
      margin-top: 1rem;
      margin-bottom: 0.3rem;
      color: #c9d1d9;
      font-size: 0.9rem;
    }
    .converter-box input,
    .converter-box select {
      margin: 0.5rem 0;
      padding: 0.6rem;
      border-radius: 8px;
      border: none;
      width: 100%;
      background: #0d1117;
      color: white;
      border: 1px solid #30363d;
      font-size: 1rem;
    }
    .converter-box button {
      margin-top: 1rem;
      padding: 0.8rem 1.5rem;
      background: #238636;
      color: white;
      border: none;
      border-radius: 10px;
      cursor: pointer;
      font-weight: bold;
      transition: 0.3s;
    }
    .converter-box button:hover {
      background: #2ea043;
    }
    .converter-box .result {
      margin-top: 1.5rem;
      color: #7ee787;
      font-size: 1.2rem;
      font-weight: bold;
      transition: all 0.3s ease-in-out;
    }

    footer {
      padding: 2rem;
      text-align: center;
      background: #161b22;
      color: #8b949e;
      font-size: 0.9rem;
    }

    .contact-section {
      background: #0d1117;
      padding: 3rem 1rem;
      text-align: center;
    }
    .contact-section form {
      max-width: 500px;
      margin: auto;
      display: flex;
      flex-direction: column;
      gap: 1rem;
    }
    .contact-section input, .contact-section textarea {
      padding: 0.8rem;
      border-radius: 8px;
      background: #161b22;
      border: 1px solid #30363d;
      color: white;
      font-family: 'Fira Code', monospace;
    }
    .contact-section button {
      padding: 0.8rem;
      border: none;
      background: #58a6ff;
      color: #fff;
      font-weight: bold;
      border-radius: 8px;
      cursor: pointer;
    }

    @media (max-width: 768px) {
      nav {
        display: none;
        flex-direction: column;
        width: 100%;
        margin-top: 1rem;
      }
      nav.active {
        display: flex;
      }
      .menu-toggle {
        display: block;
      }
    }
  </style>
</head>
<body>
  <header>
    <div class="logo">Drew Software</div>
    <button class="menu-toggle" onclick="toggleMenu()">☰</button>
    <nav id="navbar">
      <a href="#projects">Projects</a>
      <a href="#articles">Articles</a>
      <a href="convert.php">Converter</a>
      <a href="#contact">Contact</a>
    </nav>
  </header>

  <section id="projects">
    <h2>Projects</h2>

    <div class="project">
      <h3>Game Top-Up Panel</h3>
      <p>Custom website untuk top-up Mobile Legends, PUBG, dan lainnya.</p>
      <div class="live-code-box" id="code-box-3"></div>
    </div>

    <div class="project">
      <h3>Social Media Dashboard</h3>
      <p>Dashboard lengkap untuk mengelola akun dan performa media sosial.</p>
      <div class="live-code-box" id="code-box-4"></div>
    </div>

    <div class="project">
      <h3>FiveM Server Manager</h3>
      <p>Panel kontrol dan codingan untuk mengelola resource server FiveM.</p>
      <div class="live-code-box" id="code-box-1"></div>
    </div>

    <div class="project">
      <h3>Steam ID Checker</h3>
      <p>Alat untuk memverifikasi akun dan ID Steam.</p>
      <div class="live-code-box" id="code-box-2"></div>
    </div>
  </section>

  <section id="articles">
    <h2>Live Market & Articles</h2>
    <div class="article">
      <h3>Live Global Stock Price</h3>
      <div class="stock-animation" id="stock-box"></div>
    </div>
  </section>

  
    </div>
  </section>

  <section id="contact" class="contact-section">
    <h2>Contact Me</h2>
    <form>
      <input type="text" placeholder="Your Name" required />
      <input type="email" placeholder="Your Email" required />
      <textarea rows="5" placeholder="Your Message" required></textarea>
      <button type="submit">Send Message</button>
    </form>
  </section>

  <footer>
    <p>&copy; 2025 Drew Software. All rights reserved.</p>
  </footer>

  <script>
    function toggleMenu() {
      document.getElementById('navbar').classList.toggle('active');
    }

    window.addEventListener("DOMContentLoaded", () => {
      const codeBlocks = [
        `RegisterServerEvent("onPlayerJoin")
AddEventHandler("onPlayerJoin", function()
  print("Player joined: " .. GetPlayerName(source))
end)`,
        `fetch('https://api.steampowered.com/ISteamUser/GetPlayerSummaries/v2/?key=YOURKEY&steamids=123456')
.then(res => res.json())
.then(data => console.log(data))`,
        `const topUp = (game, userId, amount) => {
  return fetch('/api/topup', {
    method: 'POST',
    body: JSON.stringify({ game, userId, amount })
  });
};`,
        `const dashboardData = await fetch('/api/social/insights')
  .then(res => res.json());
console.log(dashboardData);`
      ];

      codeBlocks.forEach((code, idx) => {
        let i = 0;
        const target = document.querySelector('#code-box-' + (idx + 1));
        if (!target) return;
        function type() {
          if (i < code.length) {
            target.textContent += code.charAt(i);
            i++;
            setTimeout(type, 20);
          }
        }
        type();
      });

      const stockBox = document.getElementById("stock-box");
      const stocks = ["USD/JPY", "EUR/USD", "GBP/IDR", "AUD/USD"];
      function updateStock() {
        let html = "";
        stocks.forEach(pair => {
          const value = (Math.random() * 100).toFixed(2);
          const change = (Math.random() * 2 - 1).toFixed(2);
          const isUp = change >= 0;
          html += `<div>${pair}: ${value} <span style="color:${isUp ? '#26a641' : '#f85149'}">(${isUp ? '+' : ''}${change}%)</span></div>`;
        });
        stockBox.innerHTML = html;
      }
      updateStock();
      setInterval(updateStock, 3000);
    });

    const rates = {
      USD: { USD: 1, EUR: 0.91, IDR: 16000, JPY: 140 },
      EUR: { USD: 1.1, EUR: 1, IDR: 17500, JPY: 150 },
      IDR: { USD: 0.000062, EUR: 0.000057, IDR: 1, JPY: 0.0085 },
      JPY: { USD: 0.0071, EUR: 0.0066, IDR: 118, JPY: 1 }
    };

    function convertCurrency() {
      const amount = parseFloat(document.getElementById("amount").value);
      const from = document.getElementById("from-currency").value;
      const to = document.getElementById("to-currency").value;
      const rate = rates[from][to];
      const result = amount * rate;
      document.getElementById("result").innerText = `${amount} ${from} = ${result.toFixed(2)} ${to}`;
    }
  </script>
</body>
</html>
