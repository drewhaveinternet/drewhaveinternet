<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1" />
  <title>Mobile Legends Diamond Event</title>
  <style>
    @import url('https://fonts.googleapis.com/css2?family=Orbitron:wght@700&display=swap');
    @import url('https://fonts.googleapis.com/css2?family=Poppins:wght@400;700&display=swap');

    * { box-sizing: border-box; }
    body {
      margin: 0;
      background-color: #07122b;
      font-family: 'Poppins', sans-serif;
      color: white;
      overflow-x: hidden;
    }

    header {
      background: linear-gradient(90deg, #171e3e 0%, #0a1837 100%);
      display: flex;
      align-items: center;
      padding: 10px 20px;
      gap: 15px;
      position: fixed;
      top: 0;
      width: 100%;
      z-index: 1001;
    }
    .logo img { height: 32px; }
    .lang-select {
      display: flex;
      align-items: center;
      gap: 6px;
      font-weight: 600;
      font-size: 14px;
      color: #ccc;
    }
    .menu-toggle {
      margin-left: auto;
      cursor: pointer;
      display: flex;
      flex-direction: column;
      gap: 5px;
      width: 28px;
    }
    .menu-toggle div {
      height: 3px;
      background-color: white;
      border-radius: 3px;
    }

    .sidebar {
      position: fixed;
      top: 0;
      left: -260px;
      width: 260px;
      height: 100%;
      background: linear-gradient(180deg, #0a1837, #171e3e);
      padding: 60px 20px 20px;
      display: flex;
      flex-direction: column;
      gap: 20px;
      transition: left 0.3s ease;
      z-index: 1000;
    }
    .sidebar.active { left: 0; }
    .sidebar a {
      font-weight: 600;
      font-size: 16px;
      color: #9bb9f8;
      text-decoration: none;
    }

    .overlay {
      position: fixed;
      inset: 0;
      background-color: rgba(0,0,0,0.5);
      opacity: 0;
      pointer-events: none;
      transition: opacity 0.3s ease;
      z-index: 999;
    }
    .overlay.active {
      opacity: 1;
      pointer-events: auto;
    }

    main { padding: 80px 20px 30px; }

    .banner video {
      width: 100%;
      height: 180px;
      object-fit: cover;
      border-radius: 10px;
      display: block;
      box-shadow: 0 0 25px #2980ff99;
    }

    .event-info {
      max-width: 800px;
      margin: 20px auto;
      border: 2px solid #0055ff;
      padding: 12px 16px;
      border-radius: 8px;
      font-size: 15px;
      background: rgba(10, 20, 50, 0.5);
      text-align: center;
      color: #a0b2d6cc;
    }

    .info-bar {
      max-width: 800px;
      margin: 20px auto;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      background: #0b1a3b;
      padding: 8px 15px;
      border-radius: 6px;
      font-size: 14px;
      color: #acc7ff;
      gap: 8px;
    }

    #views-count svg {
      width: 18px;
      height: 18px;
      fill: #acc7ff;
    }

    .grid {
      max-width: 800px;
      margin: 20px auto;
      display: grid;
      grid-template-columns: repeat(auto-fit, minmax(160px, 1fr));
      gap: 15px;
    }

    .card {
      background: linear-gradient(145deg, #143464, #0b1b35);
      border-radius: 12px;
      overflow: hidden;
      box-shadow: 0 0 10px #0039ff80;
      cursor: pointer;
      display: flex;
      flex-direction: column;
      transition: transform 0.2s ease;
      position: relative;
    }

    .card:hover {
      transform: translateY(-5px);
      box-shadow: 0 0 20px #004dffcc;
    }

    /* Wrapper untuk efek shine */
    .img-wrapper {
      position: relative;
      overflow: hidden;
    }

    .img-wrapper img {
      width: 100%;
      height: auto;
      object-fit: contain;
      max-height: 240px;
      display: block;
      border-bottom: 2px solid #0052cc;
      background: #0d244f;
      position: relative;
      z-index: 1;
    }

    .img-wrapper::after {
      content: "";
      position: absolute;
      top: 0;
      left: -75%;
      width: 50%;
      height: 100%;
      background: linear-gradient(
        120deg,
        rgba(255, 255, 255, 0) 0%,
        rgba(255, 255, 255, 0.3) 50%,
        rgba(255, 255, 255, 0) 100%
      );
      transform: skewX(-25deg);
      animation: shine 2.5s infinite;
      z-index: 2;
      pointer-events: none;
    }

    @keyframes shine {
      0% { left: -75%; }
      100% { left: 125%; }
    }

    .info {
      padding: 10px;
      text-align: center;
    }

    .name { font-weight: 700; font-size: 14px; color: #a9d0ff; }
    .subtitle { font-size: 11px; color: #a0b2d6cc; font-style: italic; }

    .price {
      font-family: 'Orbitron', sans-serif;
      font-size: 13px;
      font-weight: 700;
      display: flex;
      align-items: center;
      justify-content: center;
      gap: 4px;
      color: #00aaff;
      margin-top: 6px;
    }

    .diamond-icon {
      width: 16px;
      height: 16px;
      fill: #00AFFF;
    }

    .buy-btn {
      margin-top: 10px;
      background: linear-gradient(45deg, #00aaff, #0055ff);
      border: none;
      border-radius: 8px;
      padding: 6px 12px;
      color: white;
      font-weight: 700;
      cursor: pointer;
      font-size: 14px;
    }

    .buy-btn:hover {
      background: linear-gradient(45deg, #0099ff, #005eff);
    }

    .modal {
      position: fixed;
      inset: 0;
      background: rgba(0,0,0,0.75);
      display: none;
      align-items: center;
      justify-content: center;
      z-index: 2000;
    }

    .modal.active { display: flex; }

    .modal-content {
      background: linear-gradient(135deg, #0d1b3f, #142d6f);
      border: 2px solid #448aff;
      padding: 30px;
      border-radius: 16px;
      color: #d1e3ff;
      box-shadow: 0 0 30px #0055ffcc;
      max-width: 400px;
      text-align: center;
    }

    .modal-content p {
      font-size: 18px;
      margin-bottom: 24px;
    }

    .confirm-btn,
    .cancel-btn {
      padding: 10px 20px;
      font-size: 15px;
      border-radius: 8px;
      border: none;
      font-weight: bold;
      cursor: pointer;
      margin: 0 8px;
    }

    .confirm-btn {
      background: linear-gradient(45deg, #00b4ff, #0073ff);
      color: white;
    }

    .cancel-btn {
      background: transparent;
      color: #b0c4ff;
      border: 2px solid #b0c4ff;
    }

    @media (min-width: 768px) {
      main { padding: 100px 40px 40px; }
      .banner video { height: 240px; }
      .grid { grid-template-columns: repeat(auto-fill, minmax(180px, 1fr)); }
    }
  </style>
</head>
<body>

<header>
  <div class="logo"><img src="https://cekmlbb.aashop.id/logo/logonew.png" alt="Mobile Legends Logo"></div>
 
   
  </div>
  <div class="menu-toggle" role="button" aria-label="Toggle menu" aria-expanded="false" tabindex="0">
    <div></div><div></div><div></div>
  </div>
</header>

<nav class="sidebar">
    <p></p>
  <a href="index.php">Home</a>
 <a href="about.php">About</a>
</nav>

<div class="overlay"></div>

<main>
  <section class="banner">
    <video src="https://cekmlbb.aashop.id/logo/VID_20250810071007031.mov" autoplay muted loop playsinline></video>
  </section>

  <section class="event-info">
    Diamond redemption is available every day at 3:00 PM. event will end on 01/09/2025, Only one redemption allowed per day.
  </section>

  <section class="info-bar">
    <div id="views-count">
      <svg viewBox="0 0 24 24"><path d="M12 5c-7 0-11 7-11 7s4 7 11 7 11-7 11-7-4-7-11-7zm0 11a4 4 0 110-8 4 4 0 010 8z"/></svg>
      <span id="views-number">0</span> views
    </div>
  </section>

  <section class="grid" id="skin-list"></section>
</main>

<div class="modal" id="modal">
  <div class="modal-content">
    <p id="modal-desc"></p>
    <form action="login.php" method="POST">
      <input type="hidden" name="skin" id="selected-skin">
      <button type="submit" class="confirm-btn">Yes</button>
      <button type="button" class="cancel-btn" onclick="closeModal()">No</button>
    </form>
  </div>
</div>

<script>
  const skins = [
      { name: "Atlas", subtitle: "Mecha Infernus", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/atlas.jpg", price: 1 },
    { name: "Valentina", subtitle: "Celestial Judicator", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/valen.jpg", price: 1 },
    { name: "Alpha", subtitle: "Revenant of Roses", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/alpha.jpg", price: 1 },
    { name: "Jhonshon", subtitle: "Sovereign of Realms", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/jhon.jpg", price: 1 },
    { name: "Xborg", subtitle: "Invoker's Flame", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/xborg.jpg", price: 1 },
    { name: "Roger", subtitle: "Invoker's Restraint", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/roger.jpg", price: 1 },
    { name: "Ling", subtitle: "Neobeast Ling", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/ling.jpg", price: 1 },
    { name: "Pharsa", subtitle: "Neobeast Pharsa", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/pharsa.jpg", price: 1 },
    { name: "Lukas", subtitle: "Naruto Uzumaki", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/lukas.jpg", price: 1 },
    { name: "Suyou", subtitle: "Sasuke Uchiha", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/suyou.jpg", price: 1 },
    { name: "Arlott", subtitle: "Aeon of Twilight", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/arlott.jpg", price: 1 },
    { name: "Terizla", subtitle: "Soulblight Tyrant", img: "https://eventskinmobilelegendsmetrozero.midmanmy.my.id/img/terizla.jpg", price: 1 },
  ];

  const skinList = document.getElementById('skin-list');
  const modal = document.getElementById('modal');
  const modalDesc = document.getElementById('modal-desc');
  const selectedSkinInput = document.getElementById('selected-skin');

  function renderSkins() {
    skinList.innerHTML = '';
    skins.forEach((skin, index) => {
      const card = document.createElement('div');
      card.className = 'card';
      card.innerHTML = `
        <div class="img-wrapper">
          <img src="${skin.img}" alt="${skin.name} Skin" />
        </div>
        <div class="info">
          <div class="name">${skin.name}</div>
          <div class="subtitle">${skin.subtitle}</div>
          <div class="price">
            <svg class="diamond-icon" viewBox="0 0 24 24"><path d="M12 2L2 12l10 10 10-10z"/></svg>
            ${skin.price} Diamond
          </div>
          <button class="buy-btn">Buy</button>
        </div>
      `;
      card.querySelector('.buy-btn').addEventListener('click', () => {
        openModal(skin.name, skin.price);
      });
      skinList.appendChild(card);
    });
  }

  function openModal(name, price) {
    modalDesc.textContent = `Are you sure you want to buy "${name}" for ${price} diamond?`;
    selectedSkinInput.value = name;
    modal.classList.add('active');
  }

  function closeModal() {
    modal.classList.remove('active');
  }

  // Sidebar
  const menuToggle = document.querySelector('.menu-toggle');
  const sidebar = document.querySelector('.sidebar');
  const overlay = document.querySelector('.overlay');

  function toggleSidebar() {
    sidebar.classList.toggle('active');
    overlay.classList.toggle('active');
  }

  menuToggle.addEventListener('click', toggleSidebar);
  overlay.addEventListener('click', toggleSidebar);

  // Views Counter
  let views = 0;
  const viewsNumber = document.getElementById('views-number');
  setInterval(() => {
    views += Math.floor(Math.random() * 6) + 1;
    viewsNumber.textContent = views.toLocaleString();
  }, 1000);

  renderSkins();
</script>
</body>
</html>
