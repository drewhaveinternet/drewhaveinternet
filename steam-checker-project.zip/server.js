const express = require("express");
const fetch = require("node-fetch");
const app = express();
const PORT = process.env.PORT || 3000;

app.get("/steam-id/:id", async (req, res) => {
  const steamId = req.params.id;
  const profileUrl = `https://steamcommunity.com/profiles/${steamId}`;

  try {
    const response = await fetch(profileUrl);
    const html = await response.text();

    const match = html.match(/<script type="text/javascript">[\s\S]*?<div class="responsive_page_content">/);
    if (!match) return res.status(404).send("Data tidak ditemukan atau akun private.");

    res.send(html);
  } catch (error) {
    res.status(500).send("Terjadi kesalahan server.");
  }
});

app.listen(PORT, () => console.log(`Server jalan di http://localhost:${PORT}`));